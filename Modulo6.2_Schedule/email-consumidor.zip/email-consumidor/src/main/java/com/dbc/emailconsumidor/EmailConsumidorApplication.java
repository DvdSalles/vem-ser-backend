package com.dbc.emailconsumidor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailConsumidorApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailConsumidorApplication.class, args);
	}

}
