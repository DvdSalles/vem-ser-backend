package com.dbc.emailconsumidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailConsumidorApplicationTests {

	@Test
	void contextLoads() {
	}

}
