package com.dbc.veiculoprodutorconsumidor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeiculoProdutorConsumidorApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeiculoProdutorConsumidorApplication.class, args);
	}

}
