package com.dbc.chatkafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatKafkaApplication.class, args);
	}

}
